"""Avtomatlashtirilgan testlar to'plami."""
